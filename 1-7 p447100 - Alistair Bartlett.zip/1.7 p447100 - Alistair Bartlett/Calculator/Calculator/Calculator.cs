﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

//Alistair Bartlett
//P447100
//11/05/2018
//Calculator and Dynamic Linked Library.
//The Calculator program uses 3 Linked Librarys to perform mathematical calculations from inputs
//received by the calculator Form.

namespace Calculator
{
    public partial class Calculator : Form
    {
        public Calculator()
        {
            InitializeComponent();
        }

        //************************** Methods Start *************************************************
        //Button Click Methods
        //
        //******************************************************************************************
        //
        //************************* Number Buttons *************************************************

            //The button on Click methods for the Numeric values simply add there value to the display text box.
        private void btnZero_Click(object sender, EventArgs e)
        {
            tbDisplay.Text = tbDisplay.Text + btnZero.Text;
        }

        private void btnOne_Click(object sender, EventArgs e)
        {
            tbDisplay.Text = tbDisplay.Text + btnOne.Text;
        }

        private void btnTwo_Click(object sender, EventArgs e)
        {
            tbDisplay.Text = tbDisplay.Text + btnTwo.Text;
        }

        private void btnThree_Click(object sender, EventArgs e)
        {
            tbDisplay.Text = tbDisplay.Text + btnThree.Text;
        }

        private void btnFour_Click(object sender, EventArgs e)
        {
            tbDisplay.Text = tbDisplay.Text + btnFour.Text;
        }

        private void btnFive_Click(object sender, EventArgs e)
        {
            tbDisplay.Text = tbDisplay.Text + btnFive.Text;
        }

        private void btnSix_Click(object sender, EventArgs e)
        {
            tbDisplay.Text = tbDisplay.Text + btnSix.Text;
        }

        private void btnSeven_Click(object sender, EventArgs e)
        {
            tbDisplay.Text = tbDisplay.Text + btnSeven.Text;
        }

        private void btnEight_Click(object sender, EventArgs e)
        {
            tbDisplay.Text = tbDisplay.Text + btnEight.Text;
        }

        private void btnNine_Click(object sender, EventArgs e)
        {
            tbDisplay.Text = tbDisplay.Text + btnNine.Text;
        }

        //Decimal Point Button Click
        //Adds a decimal point to the display.
        private void btnDecimalPoint_Click(object sender, EventArgs e)
        {
            tbDisplay.Text = tbDisplay.Text + btnDecimalPoint.Text;
        }

        //Clear Button Click
        //Clears the calculators display text box.
        private void btnClear_Click(object sender, EventArgs e)
        {
            tbDisplay.Clear();
        }

        //************************** Button Operator Methods ***************************************

        double total1 = 0;
        double total2 = 0;
        double result = 0;

        bool plusButtonClicked = false;
        bool minusButtonClicked = false;
        bool divideButtonClicked = false;
        bool multiplyButtonClicked = false;

        //Add Button Click
        //When add is clicked the value from the textbox is assigned to total1 variable
        //and the boolean plusButtonClicked is set to true. The function is similar for
        //Add , Subtract, Divide and Multiply buttons. The Equals button at the end
        //uses the boolean values to update the display with the correct calculation.
        private void btnAdd_Click(object sender, EventArgs e)
        {
            total1 += double.Parse(tbDisplay.Text);
            tbDisplay.Clear();

            plusButtonClicked = true;
            minusButtonClicked = false;
            divideButtonClicked = false;
            multiplyButtonClicked = false;
        }

        //Subtraction Button Click
        private void btnSubtraction_Click(object sender, EventArgs e)
        {           
                total1 += double.Parse(tbDisplay.Text);
                tbDisplay.Clear();

                plusButtonClicked = false;
                minusButtonClicked = true;
                divideButtonClicked = false;
                multiplyButtonClicked = false;   
        }

        //Divide Button Click
        private void btnDivide_Click(object sender, EventArgs e)
        {
            total1 += double.Parse(tbDisplay.Text);
            tbDisplay.Clear();

            plusButtonClicked = false;
            minusButtonClicked = false;
            divideButtonClicked = true;
            multiplyButtonClicked = false;
        }

        //Multiply Button Click
        private void btnMultiply_Click(object sender, EventArgs e)
        {

            total1 += double.Parse(tbDisplay.Text);
            
            tbDisplay.Clear();

            plusButtonClicked = false;
            minusButtonClicked = false;
            divideButtonClicked = false;
            multiplyButtonClicked = true;
        }

        //********************Square Root, Cube Root, Inverse **************************************
        //these buttons share a similar function to call to the Advanced Maths Library to calculate 
        //there results. Some error catching takes place within Square root not accepting 0 or 
        //negative values.

        //Square Root Button Click
        private void btnSqrt_Click(object sender, EventArgs e)
        {
            double num = double.Parse(tbDisplay.Text);
            if (num >= 0)
            {
                tbDisplay.Text = AdvancedMath.Algebraic.Sqrt(num).ToString();
            }
            else if(num == 0)
            {
                tbDisplay.Text = "invalid";
            }
            else
            {
                MessageBox.Show("Number must be positive !", "Error Message");
                tbDisplay.Text = "0";
            }
        }

        //Cube Root Button Click
        private void btnCubeRT_Click(object sender, EventArgs e)
        {
            double num = double.Parse(tbDisplay.Text);
            tbDisplay.Text = AdvancedMath.Algebraic.Cubert(num).ToString();
        }

        //Inverse Button Click
        private void btnInverse_Click(object sender, EventArgs e)
        {
            double num = double.Parse(tbDisplay.Text);
            tbDisplay.Text = AdvancedMath.Algebraic.Inverse(num).ToString();                 
        }

        //************************** Trigonometry Buttons ******************************************
        //The Trigonomety buttons are all calls to a linked library and virtually identical
        //The only difference is the error catching in Tan for 90 and 270.
        //Tan Button Click
        private void btnTan_Click(object sender, EventArgs e)
        {            
            if (tbDisplay.Text == "90" || tbDisplay.Text == "270")
            {
                tbDisplay.Text = "invalid";
            }
            else
            {
                double num = double.Parse(tbDisplay.Text);
                tbDisplay.Text = Trigonometry.Trigonometry.Tan(num).ToString();
            }
        }

        //Sine Button Click
        private void btnSine_Click(object sender, EventArgs e)
        {
            double num = double.Parse(tbDisplay.Text);
            tbDisplay.Text = Trigonometry.Trigonometry.Sin(num).ToString();
        }

        //Cosine Button Click
        private void btnCosine_Click(object sender, EventArgs e)
        {
            double num = double.Parse(tbDisplay.Text);
            tbDisplay.Text = Trigonometry.Trigonometry.Cos(num).ToString();
        }

        //******************************* Equals ***************************************************
        //Equals Button Click
        //Equals method is a large if statement that identifies which button has been clicked by the boolean values.
        //then executes a specific mathematical function based on the button clicked, using the values present in the text box.
        //the mathematical functions
        private void btnEquals_Click(object sender, EventArgs e)
        {
            if (plusButtonClicked == true)
            {
                total2 = double.Parse(tbDisplay.Text);
                result = BasicMath.Arithmetic.Add(total1, total2);
            }
            else if (minusButtonClicked == true)
            {
                total2 = double.Parse(tbDisplay.Text);
                result = BasicMath.Arithmetic.Sub(total1, total2);
            }
            else if (divideButtonClicked == true)
            {
                total2 = double.Parse(tbDisplay.Text);
                result = BasicMath.Arithmetic.Div(total1, total2);

                //Catching Divide by 0's Infinity string.
                if ((result.ToString()) == "Infinity")
                {
                    MessageBox.Show("Cannot Divide by Zero.");
                    result = 0;
                }
            }
            else if (multiplyButtonClicked == true)
            {
                total2 = double.Parse(tbDisplay.Text);
                result = BasicMath.Arithmetic.Multi(total1, total2);
            }
            tbDisplay.Text = result.ToString();
            total1 = 0;
        }

        //************************* Negative Number Button *****************************************
        //this allows the number currently in the calculator to be quickly turned negative
        //or vice versa from negative to positive.
        private void btnNegative_Click(object sender, EventArgs e)
        {
            if (!(tbDisplay.Text.Contains("-")))
            {
                string a = ("-" + tbDisplay.Text);
                tbDisplay.Text = a;
            }
            else
            {
                tbDisplay.Text = tbDisplay.Text.TrimStart('-');
            }
        }

        //******************************* Tools Strip Menu *****************************************
        //The File Tool Strip Menu.
        private void fileToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //this is the root of the File strip menu and does nothing.
        }

        //The Quit Tool Strip Menu Item.
        //Gives the user the option to really quit (end program) or cancel.
        private void quitToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Really Quit?", "Exit", MessageBoxButtons.OKCancel) == DialogResult.OK)
            {
                Application.Exit();
            }
        }

        //The Clear Tools Strip Menut Item
        //Simply clears the calculators display.
        private void clearToolStripMenuItem_Click(object sender, EventArgs e)
        {
            tbDisplay.Clear();
        }

        //************************** Methods End ***************************************************
    }
}
