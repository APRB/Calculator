﻿using System;

//Alistair Bartlett
//P447100
//11/05/2018
//The Advanced Math linked librarys is part of the Calculator Program and has methods to
//perform the more complicated calculations. Square Root, Cube Root and Inverse.

namespace AdvancedMath
{
    public class Algebraic
    {
        public static double Sqrt(double a)
        {
            return Math.Round(Math.Sqrt(a),3);
        }

        public static double Cubert(double a)
        {
            string result = a.ToString();

            if (result.Contains("-"))
            {
                double r = Math.Pow((-1.0 * a), (1.0 / 3.0));
                string s = "-" + r.ToString();
                r = double.Parse(s);
                return r;
            }
            else
            {
                double r = Math.Pow((1.0 * a), (1.0 / 3.0));
                return r;
            }
        }

        public static double Inverse(double a)
        {
            return Math.Round((1 / a),3);
        }
    }
}
