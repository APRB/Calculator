﻿using System;

namespace Trigonometry
{
    public class Trigonometry
    {

        public static double Tan(double a)
        {
            return Math.Round(Math.Tan(a * (Math.PI / 180.0)),3);
        }

        public static double Sin(double a)
        {
            return Math.Round(Math.Sin(Math.PI * (a / 180.0)),3);
        }

        public static double Cos(double a)
        {
            return Math.Round(Math.Cos(Math.PI * (a / 180.0)),3);
        }

    }
}
