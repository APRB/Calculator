﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//Alistair Bartlett
//P447100
//11/05/2018
//Part of the Calculator program. The Linked library for the Basic Mathematical calculations.

namespace BasicMath
{
    public class Arithmetic
    {
        //The Basic arithemtic methods need no explanation.
        //they are overloaded to accept both integers and doubles.
        public static double Add(double a, double b)
        {
            return (a + b);
        }

        public static int Add(int a, int b)
        {
            return (a + b);
        }

        public static double Sub(double a, double b)
        {
            return (a - b);
        }

        public static int Sub(int a, int b)
        {
            return (a - b);
        }

        public static double Div(double a, double b)
        {
            return (a / b);

        }

        public static int Div(int a, int b)
        {
            return (a / b);

        }

        public static double Multi(double a, double b)
        {
            return (a * b);
        }

        public static int Multi(int a, int b)
        {
            return (a * b);
        }

    }
}
